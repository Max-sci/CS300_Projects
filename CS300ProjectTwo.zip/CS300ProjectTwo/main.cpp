// CS 300 Project Two
// By: Maxwell J. Sciola
// 04/17/2025

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>

using namespace std;

// Course structure
struct Course {
    string courseNumber;
    string courseTitle;
    vector<string> prerequisites;
};

// TreeNode for BST
struct TreeNode {
    Course course;
    TreeNode* left;
    TreeNode* right;

    TreeNode(Course c) : course(c), left(nullptr), right(nullptr) {}
};

// Binary Search Tree class
class BinarySearchTree {
private:
    TreeNode* root;

    void InsertRecursive(TreeNode*& node, Course course) {
        if (!node) {
            node = new TreeNode(course);
        } else if (course.courseNumber < node->course.courseNumber) {
            InsertRecursive(node->left, course);
        } else {
            InsertRecursive(node->right, course);
        }
    }

    void PrintInOrder(TreeNode* node) {
        if (node) {
            PrintInOrder(node->left);
            cout << node->course.courseNumber << ", " << node->course.courseTitle << endl;
            PrintInOrder(node->right);
        }
    }

    TreeNode* Search(TreeNode* node, const string& courseNumber) {
        if (!node || node->course.courseNumber == courseNumber) {
            return node;
        }
        if (courseNumber < node->course.courseNumber) {
            return Search(node->left, courseNumber);
        }
        return Search(node->right, courseNumber);
    }

public:
    BinarySearchTree() : root(nullptr) {}

    void Insert(Course course) {
        InsertRecursive(root, course);
    }

    void PrintInOrder() {
        cout << "Here is a sample schedule:\n" << endl;
        PrintInOrder(root);
    }

    void PrintCourseDetails(const string& courseNumber) {
        TreeNode* node = Search(root, courseNumber);
        if (!node) {
            cout << "Course not found." << endl;
        } else {
            cout << node->course.courseNumber << ", " << node->course.courseTitle << endl;
            if (!node->course.prerequisites.empty()) {
                cout << "Prerequisites: ";
                for (size_t i = 0; i < node->course.prerequisites.size(); ++i) {
                    cout << node->course.prerequisites[i];
                    if (i < node->course.prerequisites.size() - 1) cout << ", ";
                }
                cout << endl;
            } else {
                cout << "Prerequisites: None" << endl;
            }
        }
    }

    bool IsEmpty() const {
        return root == nullptr;
    }
};

// Helper functions
string ToUpper(string str) {
    transform(str.begin(), str.end(), str.begin(), ::toupper);
    return str;
}

vector<string> Split(const string& line) {
    vector<string> tokens;
    stringstream ss(line);
    string item;
    while (getline(ss, item, ',')) {
        tokens.push_back(item);
    }
    return tokens;
}

bool LoadCourses(const string& filename, BinarySearchTree& bst) {
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Error: File not found" << endl;
        return false;
    }

    string line;
    while (getline(file, line)) {
        vector<string> tokens = Split(line);
        if (tokens.size() < 2) {
            cout << "Error: Invalid line format" << endl;
            return false;
        }

        Course course;
        course.courseNumber = ToUpper(tokens[0]);
        course.courseTitle = tokens[1];
        for (size_t i = 2; i < tokens.size(); ++i) {
            course.prerequisites.push_back(ToUpper(tokens[i]));
        }

        bst.Insert(course);
    }

    file.close();
    cout << "File loaded successfully!" << endl;
    return true;
}

// Menu display
void DisplayMenuOptions() {
    cout << "1. Load Data Structure." << endl;
    cout << "2. Print Course List." << endl;
    cout << "3. Print Course." << endl;
    cout << "9. Exit" << endl;
}

void DisplayMenu() {
    BinarySearchTree courseTree;
    int choice;
    string input;
    bool running = true;

    cout << "Welcome to the course planner." << endl;

    while (running) {
        DisplayMenuOptions();
        cout << "\nWhat would you like to do? ";
        cin >> choice;
        cout << endl;

        switch (choice) {
            case 1: {
                string filename = "CS 300 ABCU_Advising_Program_Input.csv";
                cout << "Loading data from \"" << filename << "\"...\n" << endl;
                LoadCourses(filename, courseTree);
                break;
            }

            case 2:
                if (courseTree.IsEmpty()) {
                    cout << "Error: No data loaded. Please load file data first." << endl;
                } else {
                    courseTree.PrintInOrder();
                }
                break;

            case 3:
                if (courseTree.IsEmpty()) {
                    cout << "Error: No data loaded. Please load file data first." << endl;
                } else {
                    cout << "What course do you want to know about? ";
                    cin >> input;
                    cout << endl;
                    courseTree.PrintCourseDetails(ToUpper(input));
                }
                break;

            case 9:
                cout << "Thank you for using the course planner!" << endl;
                running = false;
                break;

            default:
                cout << choice << " is not a valid option." << endl;
                break;
        }

        if (running) {
            cout << endl;
        }
    }
}

int main() {
    DisplayMenu();
    return 0;
}